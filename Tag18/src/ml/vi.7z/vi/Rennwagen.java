package ml.vi;

public class Rennwagen extends Auto{

	public Rennwagen() {
		this.setMaxGeschwindigkeit(220);
	}
	
}
