package ml.vi;

public class Fahrrad extends Fahrzeug {

	public Fahrrad() {
		super(0, 0, 30, 2);
	}

}
