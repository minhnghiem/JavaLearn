package ml.vi;

public class Auto extends Fahrzeug {

	public Auto() {
		super(0, 0, 140, 4);
	}

	public Auto(float geschwindigkeit) {
		super(0, geschwindigkeit, 140, 4);
	}

}
