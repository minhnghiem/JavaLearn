package ml.vi.bauernhof;

public class Bauernhof {

	public Stall s;

	public Bauernhof() {
		s = new Stall();
	}

	public Bauernhof(Stall s) {
		this.s = s;
	}

}
