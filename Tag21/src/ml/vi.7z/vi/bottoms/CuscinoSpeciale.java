package ml.vi.bottoms;

import ml.vi.Bottom;

public class CuscinoSpeciale extends Bottom{

	final private int grundpreis = 495;
	
	@Override
	public int getPrice() {
		return grundpreis;
	}

	
}
