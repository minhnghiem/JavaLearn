package ml.vi.bottoms;

import ml.vi.Bottom;

public class Munchy extends Bottom{

	final private int grundpreis = 395;
	
	@Override
	public int getPrice() {
		return grundpreis;
	}

	
}
