package ml.vi.bottoms;

import ml.vi.Bottom;

public class Crusty extends Bottom{
	
	final private int grundpreis = 340;
	
	@Override
	public int getPrice() {
		return grundpreis;
	}

}
