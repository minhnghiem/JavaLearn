package ml.vi.kontovergleich;

public class Person {

	private String name;
	private String vorname;

	public void setName(String n) {
		this.name = n;
	}

	public String getName() {
		return name;
	}

	public void setVorname(String n) {
		this.vorname = n;
	}

	public String getVorname() {
		return vorname;
	}

}