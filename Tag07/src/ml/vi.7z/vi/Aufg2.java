package ml.vi;

//Aufgabe 2
//Schreiben Sie ein Programm, das einen Buchstaben in den zugeh�rigen ASCII-Wert umwandelt.
//Auf der letzten Seite sehen Sie die ASCII-Tabelle.

public class Aufg2 {

	public static void main(String[] args) {

		char a = 'a';
		int ascii = a;

		System.out.println(ascii);

	}

}
