package ml.vi;


public class DemoVariablen {

	 public static void main(String[] arg) {
		 
		 
		 int i = 120;
		 i += i+5;
		 
		 System.out.println(i);
		 
	 }
}
